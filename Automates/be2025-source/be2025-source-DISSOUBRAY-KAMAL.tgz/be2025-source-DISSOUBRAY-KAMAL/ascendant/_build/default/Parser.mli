
(* The type of tokens. *)

type token = 
  | UL_TERMINAL of (string)
  | UL_RIGHT_PAR
  | UL_RIGHT_CRO
  | UL_RIGHT_BRACE
  | UL_POINT
  | UL_OP
  | UL_NON_TERMINAL of (string)
  | UL_LEFT_PAR
  | UL_LEFT_CRO
  | UL_LEFT_BRACE
  | UL_DOLLAR
  | UL_DERIV

(* This exception is raised by the monolithic API functions. *)

exception Error

(* The monolithic API. *)

val grammaire: (Lexing.lexbuf -> token) -> Lexing.lexbuf -> (unit)
