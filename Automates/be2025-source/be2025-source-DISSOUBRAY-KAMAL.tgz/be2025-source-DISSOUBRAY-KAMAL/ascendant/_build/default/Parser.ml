
module MenhirBasics = struct
  
  exception Error
  
  let _eRR =
    fun _s ->
      raise Error
  
  type token = 
    | UL_TERMINAL of (
# 22 "Parser.mly"
       (string)
# 15 "Parser.ml"
  )
    | UL_RIGHT_PAR
    | UL_RIGHT_CRO
    | UL_RIGHT_BRACE
    | UL_POINT
    | UL_OP
    | UL_NON_TERMINAL of (
# 23 "Parser.mly"
       (string)
# 25 "Parser.ml"
  )
    | UL_LEFT_PAR
    | UL_LEFT_CRO
    | UL_LEFT_BRACE
    | UL_DOLLAR
    | UL_DERIV
  
end

include MenhirBasics

# 1 "Parser.mly"
  

(* Partie recopiee dans le fichier CaML genere. *)
(* Ouverture de modules exploites dans les actions *)
(* Declarations de types, de constantes, de fonctions, d'exceptions exploites dans les actions *)


# 45 "Parser.ml"

type ('s, 'r) _menhir_state = 
  | MenhirState02 : ('s _menhir_cell0_UL_NON_TERMINAL, _menhir_box_grammaire) _menhir_state
    (** State 02.
        Stack shape : UL_NON_TERMINAL.
        Start symbol: grammaire. *)

  | MenhirState05 : (('s, _menhir_box_grammaire) _menhir_cell1_UL_LEFT_PAR, _menhir_box_grammaire) _menhir_state
    (** State 05.
        Stack shape : UL_LEFT_PAR.
        Start symbol: grammaire. *)

  | MenhirState06 : (('s, _menhir_box_grammaire) _menhir_cell1_UL_LEFT_CRO, _menhir_box_grammaire) _menhir_state
    (** State 06.
        Stack shape : UL_LEFT_CRO.
        Start symbol: grammaire. *)

  | MenhirState07 : (('s, _menhir_box_grammaire) _menhir_cell1_UL_LEFT_BRACE, _menhir_box_grammaire) _menhir_state
    (** State 07.
        Stack shape : UL_LEFT_BRACE.
        Start symbol: grammaire. *)

  | MenhirState10 : (('s, _menhir_box_grammaire) _menhir_cell1_contenu_prod, _menhir_box_grammaire) _menhir_state
    (** State 10.
        Stack shape : contenu_prod.
        Start symbol: grammaire. *)

  | MenhirState11 : ((('s, _menhir_box_grammaire) _menhir_cell1_contenu_prod, _menhir_box_grammaire) _menhir_cell1_UL_OP, _menhir_box_grammaire) _menhir_state
    (** State 11.
        Stack shape : contenu_prod UL_OP.
        Start symbol: grammaire. *)

  | MenhirState12 : (((('s, _menhir_box_grammaire) _menhir_cell1_contenu_prod, _menhir_box_grammaire) _menhir_cell1_UL_OP, _menhir_box_grammaire) _menhir_cell1_contenu_prod, _menhir_box_grammaire) _menhir_state
    (** State 12.
        Stack shape : contenu_prod UL_OP contenu_prod.
        Start symbol: grammaire. *)

  | MenhirState13 : ((('s, _menhir_box_grammaire) _menhir_cell1_contenu_prod, _menhir_box_grammaire) _menhir_cell1_contenu_prod, _menhir_box_grammaire) _menhir_state
    (** State 13.
        Stack shape : contenu_prod contenu_prod.
        Start symbol: grammaire. *)

  | MenhirState22 : (('s _menhir_cell0_UL_NON_TERMINAL, _menhir_box_grammaire) _menhir_cell1_production, _menhir_box_grammaire) _menhir_state
    (** State 22.
        Stack shape : UL_NON_TERMINAL production.
        Start symbol: grammaire. *)

  | MenhirState24 : ((('s, _menhir_box_grammaire) _menhir_cell1_production, _menhir_box_grammaire) _menhir_cell1_UL_NON_TERMINAL, _menhir_box_grammaire) _menhir_state
    (** State 24.
        Stack shape : production UL_NON_TERMINAL.
        Start symbol: grammaire. *)

  | MenhirState26 : (((('s, _menhir_box_grammaire) _menhir_cell1_production, _menhir_box_grammaire) _menhir_cell1_UL_NON_TERMINAL, _menhir_box_grammaire) _menhir_cell1_production, _menhir_box_grammaire) _menhir_state
    (** State 26.
        Stack shape : production UL_NON_TERMINAL production.
        Start symbol: grammaire. *)


and ('s, 'r) _menhir_cell1_contenu_prod = 
  | MenhirCell1_contenu_prod of 's * ('s, 'r) _menhir_state * (unit)

and ('s, 'r) _menhir_cell1_production = 
  | MenhirCell1_production of 's * ('s, 'r) _menhir_state * (unit)

and ('s, 'r) _menhir_cell1_UL_LEFT_BRACE = 
  | MenhirCell1_UL_LEFT_BRACE of 's * ('s, 'r) _menhir_state

and ('s, 'r) _menhir_cell1_UL_LEFT_CRO = 
  | MenhirCell1_UL_LEFT_CRO of 's * ('s, 'r) _menhir_state

and ('s, 'r) _menhir_cell1_UL_LEFT_PAR = 
  | MenhirCell1_UL_LEFT_PAR of 's * ('s, 'r) _menhir_state

and ('s, 'r) _menhir_cell1_UL_NON_TERMINAL = 
  | MenhirCell1_UL_NON_TERMINAL of 's * ('s, 'r) _menhir_state * (
# 23 "Parser.mly"
       (string)
# 123 "Parser.ml"
)

and 's _menhir_cell0_UL_NON_TERMINAL = 
  | MenhirCell0_UL_NON_TERMINAL of 's * (
# 23 "Parser.mly"
       (string)
# 130 "Parser.ml"
)

and ('s, 'r) _menhir_cell1_UL_OP = 
  | MenhirCell1_UL_OP of 's * ('s, 'r) _menhir_state

and _menhir_box_grammaire = 
  | MenhirBox_grammaire of (unit) [@@unboxed]

let _menhir_action_01 =
  fun () ->
    (
# 39 "Parser.mly"
                       ((print_endline "vide"))
# 144 "Parser.ml"
     : (unit))

let _menhir_action_02 =
  fun () ->
    (
# 40 "Parser.mly"
                                                                         ((print_endline "boucle_gram : NON_TERMINAL DERIV production POINT"))
# 152 "Parser.ml"
     : (unit))

let _menhir_action_03 =
  fun () ->
    (
# 50 "Parser.mly"
                             ((print_endline "vide"))
# 160 "Parser.ml"
     : (unit))

let _menhir_action_04 =
  fun () ->
    (
# 51 "Parser.mly"
                                                          ((print_endline "OP boucle_prod"))
# 168 "Parser.ml"
     : (unit))

let _menhir_action_05 =
  fun () ->
    (
# 52 "Parser.mly"
                                                      ((print_endline "boucle_prod"))
# 176 "Parser.ml"
     : (unit))

let _menhir_action_06 =
  fun () ->
    (
# 44 "Parser.mly"
                              ((print_endline "non_terminal"))
# 184 "Parser.ml"
     : (unit))

let _menhir_action_07 =
  fun () ->
    (
# 45 "Parser.mly"
                          ((print_endline "terminal"))
# 192 "Parser.ml"
     : (unit))

let _menhir_action_08 =
  fun () ->
    (
# 46 "Parser.mly"
                                                  ((print_endline "Left_Cro production Right_Cro"))
# 200 "Parser.ml"
     : (unit))

let _menhir_action_09 =
  fun () ->
    (
# 47 "Parser.mly"
                                                      ((print_endline "Left_Brace production Right_Brace"))
# 208 "Parser.ml"
     : (unit))

let _menhir_action_10 =
  fun () ->
    (
# 48 "Parser.mly"
                                                  ((print_endline "Left_Par production Right_Par"))
# 216 "Parser.ml"
     : (unit))

let _menhir_action_11 =
  fun () ->
    (
# 37 "Parser.mly"
                                         ( (* A COMPLETER *) (print_endline "grammaire : ...") )
# 224 "Parser.ml"
     : (unit))

let _menhir_action_12 =
  fun () ->
    (
# 38 "Parser.mly"
                                                                             ((print_endline "internal_grammaire : NON_TERMINAL DERIV production POINT"))
# 232 "Parser.ml"
     : (unit))

let _menhir_action_13 =
  fun () ->
    (
# 41 "Parser.mly"
                                            ((print_endline "contenu_prod boucle_retour_prod"))
# 240 "Parser.ml"
     : (unit))

let _menhir_print_token : token -> string =
  fun _tok ->
    match _tok with
    | UL_DERIV ->
        "UL_DERIV"
    | UL_DOLLAR ->
        "UL_DOLLAR"
    | UL_LEFT_BRACE ->
        "UL_LEFT_BRACE"
    | UL_LEFT_CRO ->
        "UL_LEFT_CRO"
    | UL_LEFT_PAR ->
        "UL_LEFT_PAR"
    | UL_NON_TERMINAL _ ->
        "UL_NON_TERMINAL"
    | UL_OP ->
        "UL_OP"
    | UL_POINT ->
        "UL_POINT"
    | UL_RIGHT_BRACE ->
        "UL_RIGHT_BRACE"
    | UL_RIGHT_CRO ->
        "UL_RIGHT_CRO"
    | UL_RIGHT_PAR ->
        "UL_RIGHT_PAR"
    | UL_TERMINAL _ ->
        "UL_TERMINAL"

let _menhir_fail : unit -> 'a =
  fun () ->
    Printf.eprintf "Internal failure -- please contact the parser generator's developers.\n%!";
    assert false

include struct
  
  [@@@ocaml.warning "-4-37"]
  
  let _menhir_run_28 : type  ttv_stack. (ttv_stack _menhir_cell0_UL_NON_TERMINAL, _menhir_box_grammaire) _menhir_cell1_production -> _menhir_box_grammaire =
    fun _menhir_stack ->
      let MenhirCell1_production (_menhir_stack, _, _) = _menhir_stack in
      let MenhirCell0_UL_NON_TERMINAL (_menhir_stack, _) = _menhir_stack in
      let _ = _menhir_action_12 () in
      let _v = _menhir_action_11 () in
      MenhirBox_grammaire _v
  
  let rec _menhir_run_27 : type  ttv_stack. (((ttv_stack, _menhir_box_grammaire) _menhir_cell1_production, _menhir_box_grammaire) _menhir_cell1_UL_NON_TERMINAL, _menhir_box_grammaire) _menhir_cell1_production -> _menhir_box_grammaire =
    fun _menhir_stack ->
      let MenhirCell1_production (_menhir_stack, _, _) = _menhir_stack in
      let MenhirCell1_UL_NON_TERMINAL (_menhir_stack, _menhir_s, _) = _menhir_stack in
      let _ = _menhir_action_02 () in
      _menhir_goto_boucle_gram _menhir_stack _menhir_s
  
  and _menhir_goto_boucle_gram : type  ttv_stack. ((ttv_stack, _menhir_box_grammaire) _menhir_cell1_production as 'stack) -> ('stack, _menhir_box_grammaire) _menhir_state -> _menhir_box_grammaire =
    fun _menhir_stack _menhir_s ->
      match _menhir_s with
      | MenhirState22 ->
          _menhir_run_28 _menhir_stack
      | MenhirState26 ->
          _menhir_run_27 _menhir_stack
  
  let rec _menhir_run_03 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_grammaire) _menhir_state -> _menhir_box_grammaire =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _tok = _menhir_lexer _menhir_lexbuf in
      let _v = _menhir_action_07 () in
      _menhir_goto_contenu_prod _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_contenu_prod : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_grammaire) _menhir_state -> _ -> _menhir_box_grammaire =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState10 ->
          _menhir_run_13 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState13 ->
          _menhir_run_13 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState12 ->
          _menhir_run_13 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState11 ->
          _menhir_run_12 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState02 ->
          _menhir_run_10 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState24 ->
          _menhir_run_10 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState05 ->
          _menhir_run_10 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState06 ->
          _menhir_run_10 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState07 ->
          _menhir_run_10 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_13 : type  ttv_stack. ((ttv_stack, _menhir_box_grammaire) _menhir_cell1_contenu_prod as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_grammaire) _menhir_state -> _ -> _menhir_box_grammaire =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_contenu_prod (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | UL_TERMINAL _ ->
          _menhir_run_03 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState13
      | UL_OP ->
          _menhir_run_11 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState13
      | UL_NON_TERMINAL _ ->
          _menhir_run_04 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState13
      | UL_LEFT_PAR ->
          _menhir_run_05 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState13
      | UL_LEFT_CRO ->
          _menhir_run_06 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState13
      | UL_LEFT_BRACE ->
          _menhir_run_07 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState13
      | UL_POINT | UL_RIGHT_BRACE | UL_RIGHT_CRO | UL_RIGHT_PAR ->
          let _ = _menhir_action_03 () in
          _menhir_run_14 _menhir_stack _menhir_lexbuf _menhir_lexer _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_11 : type  ttv_stack. ((ttv_stack, _menhir_box_grammaire) _menhir_cell1_contenu_prod as 'stack) -> _ -> _ -> ('stack, _menhir_box_grammaire) _menhir_state -> _menhir_box_grammaire =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _menhir_stack = MenhirCell1_UL_OP (_menhir_stack, _menhir_s) in
      let _menhir_s = MenhirState11 in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UL_TERMINAL _ ->
          _menhir_run_03 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | UL_NON_TERMINAL _ ->
          _menhir_run_04 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | UL_LEFT_PAR ->
          _menhir_run_05 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | UL_LEFT_CRO ->
          _menhir_run_06 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | UL_LEFT_BRACE ->
          _menhir_run_07 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_run_04 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_grammaire) _menhir_state -> _menhir_box_grammaire =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _tok = _menhir_lexer _menhir_lexbuf in
      let _v = _menhir_action_06 () in
      _menhir_goto_contenu_prod _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_05 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_grammaire) _menhir_state -> _menhir_box_grammaire =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _menhir_stack = MenhirCell1_UL_LEFT_PAR (_menhir_stack, _menhir_s) in
      let _menhir_s = MenhirState05 in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UL_TERMINAL _ ->
          _menhir_run_03 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | UL_NON_TERMINAL _ ->
          _menhir_run_04 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | UL_LEFT_PAR ->
          _menhir_run_05 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | UL_LEFT_CRO ->
          _menhir_run_06 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | UL_LEFT_BRACE ->
          _menhir_run_07 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_run_06 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_grammaire) _menhir_state -> _menhir_box_grammaire =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _menhir_stack = MenhirCell1_UL_LEFT_CRO (_menhir_stack, _menhir_s) in
      let _menhir_s = MenhirState06 in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UL_TERMINAL _ ->
          _menhir_run_03 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | UL_NON_TERMINAL _ ->
          _menhir_run_04 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | UL_LEFT_PAR ->
          _menhir_run_05 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | UL_LEFT_CRO ->
          _menhir_run_06 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | UL_LEFT_BRACE ->
          _menhir_run_07 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_run_07 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_grammaire) _menhir_state -> _menhir_box_grammaire =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _menhir_stack = MenhirCell1_UL_LEFT_BRACE (_menhir_stack, _menhir_s) in
      let _menhir_s = MenhirState07 in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UL_TERMINAL _ ->
          _menhir_run_03 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | UL_NON_TERMINAL _ ->
          _menhir_run_04 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | UL_LEFT_PAR ->
          _menhir_run_05 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | UL_LEFT_CRO ->
          _menhir_run_06 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | UL_LEFT_BRACE ->
          _menhir_run_07 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_run_14 : type  ttv_stack. ((ttv_stack, _menhir_box_grammaire) _menhir_cell1_contenu_prod, _menhir_box_grammaire) _menhir_cell1_contenu_prod -> _ -> _ -> _ -> _menhir_box_grammaire =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _tok ->
      let MenhirCell1_contenu_prod (_menhir_stack, _menhir_s, _) = _menhir_stack in
      let _ = _menhir_action_05 () in
      _menhir_goto_boucle_retour_prod _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s _tok
  
  and _menhir_goto_boucle_retour_prod : type  ttv_stack. ((ttv_stack, _menhir_box_grammaire) _menhir_cell1_contenu_prod as 'stack) -> _ -> _ -> ('stack, _menhir_box_grammaire) _menhir_state -> _ -> _menhir_box_grammaire =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s _tok ->
      match _menhir_s with
      | MenhirState10 ->
          _menhir_run_16 _menhir_stack _menhir_lexbuf _menhir_lexer _tok
      | MenhirState12 ->
          _menhir_run_15 _menhir_stack _menhir_lexbuf _menhir_lexer _tok
      | MenhirState13 ->
          _menhir_run_14 _menhir_stack _menhir_lexbuf _menhir_lexer _tok
  
  and _menhir_run_16 : type  ttv_stack. (ttv_stack, _menhir_box_grammaire) _menhir_cell1_contenu_prod -> _ -> _ -> _ -> _menhir_box_grammaire =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _tok ->
      let MenhirCell1_contenu_prod (_menhir_stack, _menhir_s, _) = _menhir_stack in
      let _v = _menhir_action_13 () in
      _menhir_goto_production _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_production : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_grammaire) _menhir_state -> _ -> _menhir_box_grammaire =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState24 ->
          _menhir_run_25 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState02 ->
          _menhir_run_21 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState05 ->
          _menhir_run_19 _menhir_stack _menhir_lexbuf _menhir_lexer _tok
      | MenhirState06 ->
          _menhir_run_17 _menhir_stack _menhir_lexbuf _menhir_lexer _tok
      | MenhirState07 ->
          _menhir_run_08 _menhir_stack _menhir_lexbuf _menhir_lexer _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_25 : type  ttv_stack. (((ttv_stack, _menhir_box_grammaire) _menhir_cell1_production, _menhir_box_grammaire) _menhir_cell1_UL_NON_TERMINAL as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_grammaire) _menhir_state -> _ -> _menhir_box_grammaire =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_production (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | UL_POINT ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UL_NON_TERMINAL _v_0 ->
              _menhir_run_23 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState26
          | UL_DOLLAR ->
              let _ = _menhir_action_01 () in
              _menhir_run_27 _menhir_stack
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_23 : type  ttv_stack. ((ttv_stack, _menhir_box_grammaire) _menhir_cell1_production as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_grammaire) _menhir_state -> _menhir_box_grammaire =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_UL_NON_TERMINAL (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UL_DERIV ->
          let _menhir_s = MenhirState24 in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UL_TERMINAL _ ->
              _menhir_run_03 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | UL_NON_TERMINAL _ ->
              _menhir_run_04 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | UL_LEFT_PAR ->
              _menhir_run_05 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | UL_LEFT_CRO ->
              _menhir_run_06 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | UL_LEFT_BRACE ->
              _menhir_run_07 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_21 : type  ttv_stack. (ttv_stack _menhir_cell0_UL_NON_TERMINAL as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_grammaire) _menhir_state -> _ -> _menhir_box_grammaire =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_production (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | UL_POINT ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UL_NON_TERMINAL _v_0 ->
              _menhir_run_23 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState22
          | UL_DOLLAR ->
              let _ = _menhir_action_01 () in
              _menhir_run_28 _menhir_stack
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_19 : type  ttv_stack. (ttv_stack, _menhir_box_grammaire) _menhir_cell1_UL_LEFT_PAR -> _ -> _ -> _ -> _menhir_box_grammaire =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _tok ->
      match (_tok : MenhirBasics.token) with
      | UL_RIGHT_PAR ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell1_UL_LEFT_PAR (_menhir_stack, _menhir_s) = _menhir_stack in
          let _v = _menhir_action_10 () in
          _menhir_goto_contenu_prod _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_17 : type  ttv_stack. (ttv_stack, _menhir_box_grammaire) _menhir_cell1_UL_LEFT_CRO -> _ -> _ -> _ -> _menhir_box_grammaire =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _tok ->
      match (_tok : MenhirBasics.token) with
      | UL_RIGHT_CRO ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell1_UL_LEFT_CRO (_menhir_stack, _menhir_s) = _menhir_stack in
          let _v = _menhir_action_08 () in
          _menhir_goto_contenu_prod _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_08 : type  ttv_stack. (ttv_stack, _menhir_box_grammaire) _menhir_cell1_UL_LEFT_BRACE -> _ -> _ -> _ -> _menhir_box_grammaire =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _tok ->
      match (_tok : MenhirBasics.token) with
      | UL_RIGHT_BRACE ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell1_UL_LEFT_BRACE (_menhir_stack, _menhir_s) = _menhir_stack in
          let _v = _menhir_action_09 () in
          _menhir_goto_contenu_prod _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_15 : type  ttv_stack. (((ttv_stack, _menhir_box_grammaire) _menhir_cell1_contenu_prod, _menhir_box_grammaire) _menhir_cell1_UL_OP, _menhir_box_grammaire) _menhir_cell1_contenu_prod -> _ -> _ -> _ -> _menhir_box_grammaire =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _tok ->
      let MenhirCell1_contenu_prod (_menhir_stack, _, _) = _menhir_stack in
      let MenhirCell1_UL_OP (_menhir_stack, _menhir_s) = _menhir_stack in
      let _ = _menhir_action_04 () in
      _menhir_goto_boucle_retour_prod _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s _tok
  
  and _menhir_run_12 : type  ttv_stack. (((ttv_stack, _menhir_box_grammaire) _menhir_cell1_contenu_prod, _menhir_box_grammaire) _menhir_cell1_UL_OP as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_grammaire) _menhir_state -> _ -> _menhir_box_grammaire =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_contenu_prod (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | UL_TERMINAL _ ->
          _menhir_run_03 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState12
      | UL_OP ->
          _menhir_run_11 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState12
      | UL_NON_TERMINAL _ ->
          _menhir_run_04 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState12
      | UL_LEFT_PAR ->
          _menhir_run_05 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState12
      | UL_LEFT_CRO ->
          _menhir_run_06 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState12
      | UL_LEFT_BRACE ->
          _menhir_run_07 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState12
      | UL_POINT | UL_RIGHT_BRACE | UL_RIGHT_CRO | UL_RIGHT_PAR ->
          let _ = _menhir_action_03 () in
          _menhir_run_15 _menhir_stack _menhir_lexbuf _menhir_lexer _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_10 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_grammaire) _menhir_state -> _ -> _menhir_box_grammaire =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_contenu_prod (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | UL_TERMINAL _ ->
          _menhir_run_03 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState10
      | UL_OP ->
          _menhir_run_11 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState10
      | UL_NON_TERMINAL _ ->
          _menhir_run_04 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState10
      | UL_LEFT_PAR ->
          _menhir_run_05 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState10
      | UL_LEFT_CRO ->
          _menhir_run_06 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState10
      | UL_LEFT_BRACE ->
          _menhir_run_07 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState10
      | UL_POINT | UL_RIGHT_BRACE | UL_RIGHT_CRO | UL_RIGHT_PAR ->
          let _ = _menhir_action_03 () in
          _menhir_run_16 _menhir_stack _menhir_lexbuf _menhir_lexer _tok
      | _ ->
          _eRR ()
  
  let _menhir_run_00 : type  ttv_stack. ttv_stack -> _ -> _ -> _menhir_box_grammaire =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer ->
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UL_NON_TERMINAL _v ->
          let _menhir_stack = MenhirCell0_UL_NON_TERMINAL (_menhir_stack, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UL_DERIV ->
              let _menhir_s = MenhirState02 in
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | UL_TERMINAL _ ->
                  _menhir_run_03 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
              | UL_NON_TERMINAL _ ->
                  _menhir_run_04 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
              | UL_LEFT_PAR ->
                  _menhir_run_05 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
              | UL_LEFT_CRO ->
                  _menhir_run_06 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
              | UL_LEFT_BRACE ->
                  _menhir_run_07 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
              | _ ->
                  _eRR ())
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
end

let grammaire =
  fun _menhir_lexer _menhir_lexbuf ->
    let _menhir_stack = () in
    let MenhirBox_grammaire v = _menhir_run_00 _menhir_stack _menhir_lexbuf _menhir_lexer in
    v

# 56 "Parser.mly"
                

# 657 "Parser.ml"
